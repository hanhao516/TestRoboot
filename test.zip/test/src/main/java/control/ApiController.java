package control;

import com.jfinal.core.Controller;
import util.HttpClientUtil;

public class ApiController extends Controller {
	
	public void hello() {
		String url = "https://www.taobao.com/";
		String jsonStr = "{xxx}";
		String httpOrgCreateTestRtn = HttpClientUtil.doPost(url, jsonStr, "utf-8");
		renderJson(httpOrgCreateTestRtn);
	}



}
